#include <stdio.h>
#include <assert.h>

// Define the external assembly functions
extern "C" int solution_for_grade_6(int const* arr, unsigned int arr_size);
extern "C" int solution_for_grade_7(int const* arr, unsigned int arr_size);
extern "C" int solution_for_grade_9(int const* arr, unsigned int arr_size);

int main() {
    // Test data
    int arr1[] = { 3, -5, 2, 10, -8, 15 };
    int arr2[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
    int arr3[] = { 0, -2, -4, -6, -8 };

    // Test solution_for_grade_6
    int result1 = solution_for_grade_6(arr1, sizeof(arr1) / sizeof(arr1[0]));
    printf("Maximal value in arr1: %d\n", result1);
    assert(result1 == 15);

    int result2 = solution_for_grade_6(arr2, sizeof(arr2) / sizeof(arr2[0]));
    printf("Maximal value in arr2: %d\n", result2);
    assert(result2 == 9);

    int result3 = solution_for_grade_6(arr3, sizeof(arr3) / sizeof(arr3[0]));
    printf("Maximal value in arr3: %d\n", result3);
    assert(result3 == 0);

    // Test solution_for_grade_7
    int result4 = solution_for_grade_7(arr1, sizeof(arr1) / sizeof(arr1[0]));
    printf("Total of even values in arr1: %d\n", result4);
    assert(result4 == 12);

    int result5 = solution_for_grade_7(arr2, sizeof(arr2) / sizeof(arr2[0]));
    printf("Total of even values in arr2: %d\n", result5);
    assert(result5 == 20);

    int result6 = solution_for_grade_7(arr3, sizeof(arr3) / sizeof(arr3[0]));
    printf("Total of even values in arr3: %d\n", result6);
    assert(result6 == -20);

    // Test solution_for_grade_9
    int result7 = solution_for_grade_9(arr1, sizeof(arr1) / sizeof(arr1[0]));
    printf("Position of minimal positive value in arr1: %d\n", result7);
    assert(result7 == 5);

    int result8 = solution_for_grade_9(arr2, sizeof(arr2) / sizeof(arr2[0]));
    printf("Position of minimal positive value in arr2: %d\n", result8);
    assert(result8 == 0);

    int result9 = solution_for_grade_9(arr3, sizeof(arr3) / sizeof(arr3[0]));
    printf("Position of minimal positive value in arr3: %d\n", result9);
    assert(result9 == -1);

    printf("All tests passed!\n");

    return�0;
}